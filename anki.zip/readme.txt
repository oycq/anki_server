# https://zhuanlan.zhihu.com/p/25042942

1.install dependances
pip install webob PasteDeploy PasteScript sqlalchemy simplejson -i https://pypi.tuna.tsinghua.edu.cn/simple

2.install anki use zip
easy_install AnkiServer-2.0.6.tar.gz

3.add user
python ankiserverctl.py add

3.test
python ankiserverctl.py debug

4.run
python  ankiserverctl.py start

5.stop
python  ankiserverctl.py stop

